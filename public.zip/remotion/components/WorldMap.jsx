import React from "react";
import { Img, staticFile, useCurrentFrame, interpolate } from "remotion";

export const WorldMap = ({ opacity = 1, scale = 1 }) => {
    const frame = useCurrentFrame();

    const extraScale = interpolate(frame, [0, 120], [1, 1.04], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
    });

    return (
        <div
            style={{
                position: "absolute",
                inset: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                opacity,
                transform: `scale(${scale * extraScale})`,
            }}
        >
            <Img
                src={staticFile("world-map-realistic.svg")}
                style={{
                    width: "90%",
                    height: "auto",
                    opacity: 0.22,
                    filter: "drop-shadow(0 0 24px rgba(255,255,255,0.05))",
                }}
            />
        </div>
    );
};