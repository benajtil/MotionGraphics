import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../styles/theme";

export const RouteArc = ({ from, to, delay = 0, height = 140 }) => {
    const frame = useCurrentFrame();

    const progress = interpolate(frame - delay, [0, 48], [0, 1], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
    });

    const [x1, y1] = from;
    const [x2, y2] = to;
    const cx = (x1 + x2) / 2;
    const cy = Math.min(y1, y2) - height;

    const path = `M ${x1} ${y1} Q ${cx} ${cy} ${x2} ${y2}`;

    return (
        <svg
            width="1920"
            height="1080"
            viewBox="0 0 1920 1080"
            style={{ position: "absolute", inset: 0 }}
        >
            <path
                d={path}
                fill="none"
                stroke="rgba(198,124,46,0.18)"
                strokeWidth="9"
                strokeLinecap="round"
            />
            <path
                d={path}
                fill="none"
                stroke={theme.colors.amber}
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray="1200"
                strokeDashoffset={1200 - progress * 1200}
            />
        </svg>
    );
};