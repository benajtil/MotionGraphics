import React from "react";
import { Img, staticFile } from "remotion";

export const CoffeeBeanIcon = ({ size = 120, opacity = 1 }) => {
    return (
        <Img
            src={staticFile("coffee-bean-realistic.svg")}
            style={{
                width: size,
                height: size,
                opacity,
            }}
        />
    );
};