import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { popIn } from "../utils/animation";
import { theme } from "../styles/theme";

export const MapMarker = ({ x, y, title, subtitle, delay = 0 }) => {
    const frame = useCurrentFrame();
    const { fps } = useVideoConfig();
    const scale = popIn(frame, fps, delay);
    const pulse = 1 + Math.sin((frame - delay) / 8) * 0.08;

    return (
        <div
            style={{
                position: "absolute",
                left: x,
                top: y,
                transform: `translate(-50%, -50%) scale(${scale})`,
            }}
        >
            <div
                style={{
                    position: "absolute",
                    left: "50%",
                    top: "50%",
                    width: 42,
                    height: 42,
                    borderRadius: "50%",
                    background: theme.colors.amberSoft,
                    transform: `translate(-50%, -50%) scale(${pulse})`,
                    filter: "blur(2px)",
                }}
            />
            <div
                style={{
                    width: 18,
                    height: 18,
                    borderRadius: 999,
                    background: theme.colors.amber,
                    boxShadow: theme.shadowAmber,
                    margin: "0 auto",
                    position: "relative",
                    zIndex: 2,
                }}
            />
            <div
                style={{
                    marginTop: 14,
                    padding: "12px 16px",
                    borderRadius: 18,
                    background: "rgba(17,24,39,0.9)",
                    border: `1px solid ${theme.colors.line}`,
                    minWidth: 240,
                    boxShadow: "0 14px 34px rgba(0,0,0,0.32)",
                    position: "relative",
                    zIndex: 2,
                }}
            >
                <div style={{ fontSize: 22, fontWeight: 700, color: theme.colors.white }}>
                    {title}
                </div>
                <div style={{ fontSize: 16, color: theme.colors.cream, marginTop: 6 }}>
                    {subtitle}
                </div>
            </div>
        </div>
    );
};