import React from "react";
import { useCurrentFrame } from "remotion";
import { drift } from "../utils/animation";

export const BackgroundGlow = () => {
    const frame = useCurrentFrame();

    return (
        <>
            <div
                style={{
                    position: "absolute",
                    width: 700,
                    height: 700,
                    borderRadius: "50%",
                    background: "radial-gradient(circle, rgba(198,124,46,0.18) 0%, rgba(198,124,46,0.06) 35%, rgba(198,124,46,0) 70%)",
                    left: -120 + drift(frame, 30, 90),
                    top: -140,
                    filter: "blur(18px)",
                }}
            />
            <div
                style={{
                    position: "absolute",
                    width: 600,
                    height: 600,
                    borderRadius: "50%",
                    background: "radial-gradient(circle, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.02) 40%, rgba(255,255,255,0) 75%)",
                    right: -80,
                    bottom: -100 + drift(frame, 24, 110),
                    filter: "blur(18px)",
                }}
            />
        </>
    );
};