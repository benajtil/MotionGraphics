import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { popIn } from "../utils/animation";
import { theme } from "../styles/theme";

export const StatCard = ({ title, children, delay = 0 }) => {
    const frame = useCurrentFrame();
    const { fps } = useVideoConfig();
    const scale = popIn(frame, fps, delay);

    return (
        <div
            style={{
                width: 400,
                padding: 30,
                borderRadius: 30,
                background: "linear-gradient(180deg, rgba(22,30,48,0.92), rgba(12,18,31,0.92))",
                border: `1px solid ${theme.colors.line}`,
                transform: `scale(${scale})`,
                boxShadow: "0 18px 48px rgba(0,0,0,0.28)",
                backdropFilter: "blur(6px)",
            }}
        >
            <div style={{ fontSize: 17, color: theme.colors.muted, marginBottom: 14 }}>
                {title}
            </div>
            <div style={{ fontSize: 50, fontWeight: 800, color: theme.colors.white }}>
                {children}
            </div>
        </div>
    );
};