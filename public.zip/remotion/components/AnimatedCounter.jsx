import React from "react";
import { interpolate, useCurrentFrame } from "remotion";

export const AnimatedCounter = ({
    from = 0,
    to,
    duration = 45,
    suffix = "",
}) => {
    const frame = useCurrentFrame();

    const value = Math.floor(
        interpolate(frame, [0, duration], [from, to], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
        })
    );

    return (
        <>
            {value.toLocaleString()}
            {suffix}
        </>
    );
};