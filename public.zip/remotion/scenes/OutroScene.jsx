import React from "react";
import { useCurrentFrame } from "remotion";
import { fadeIn } from "../utils/animation";
import { theme } from "../styles/theme";
import { BackgroundGlow } from "../components/BackgroundGlow";

export const OutroScene = () => {
    const frame = useCurrentFrame();
    const opacity = fadeIn(frame, 0, 18);

    return (
        <div
            style={{
                flex: 1,
                position: "relative",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                textAlign: "center",
                padding: "0 120px",
                opacity,
            }}
        >
            <BackgroundGlow />
            <div style={{ position: "relative", zIndex: 2 }}>
                <div style={{ fontSize: 74, fontWeight: 800 }}>
                    Your coffee starts far from home.
                </div>
                <div
                    style={{
                        marginTop: 16,
                        fontSize: 24,
                        color: theme.colors.cream,
                    }}
                >
                    A global story in every cup.
                </div>
            </div>
        </div>
    );
};