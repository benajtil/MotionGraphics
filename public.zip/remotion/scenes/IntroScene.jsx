import React from "react";
import { useCurrentFrame } from "remotion";
import { fadeIn, fadeOut } from "../utils/animation";
import { theme } from "../styles/theme";
import { BackgroundGlow } from "../components/BackgroundGlow";
import { CoffeeBeanIcon } from "../components/CoffeeBeanIcon";

export const IntroScene = () => {
    const frame = useCurrentFrame();
    const opacity = fadeIn(frame, 0, 18) * fadeOut(frame, 42, 16);

    return (
        <div
            style={{
                flex: 1,
                position: "relative",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "column",
                opacity,
                textAlign: "center",
                padding: "0 80px",
            }}
        >
            <BackgroundGlow />
            <CoffeeBeanIcon size={110} opacity={0.95} />
            <div style={{ fontSize: 86, fontWeight: 800, letterSpacing: 2, marginTop: 18 }}>
                BEAN TO BREW
            </div>
            <div style={{ fontSize: 28, color: theme.colors.cream, marginTop: 12 }}>
                The hidden global journey of coffee
            </div>
        </div>
    );
};