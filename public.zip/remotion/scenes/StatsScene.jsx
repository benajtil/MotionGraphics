import React from "react";
import { BackgroundGlow } from "../components/BackgroundGlow";
import { StatCard } from "../components/StatCard";
import { AnimatedCounter } from "../components/AnimatedCounter";
import { stats } from "../data/coffeeData";

export const StatsScene = () => {
    return (
        <div
            style={{
                flex: 1,
                position: "relative",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                gap: 28,
                padding: "0 60px",
            }}
        >
            <BackgroundGlow />

            <StatCard title={stats[0].title} delay={0}>
                <AnimatedCounter to={stats[0].value} suffix={stats[0].suffix} />
            </StatCard>

            <StatCard title={stats[1].title} delay={8}>
                <AnimatedCounter to={stats[1].value} suffix={stats[1].suffix} />
            </StatCard>

            <StatCard title={stats[2].title} delay={16}>
                <AnimatedCounter to={stats[2].value} suffix={stats[2].suffix} />
            </StatCard>
        </div>
    );
};