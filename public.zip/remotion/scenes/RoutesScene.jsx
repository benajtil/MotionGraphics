import React from "react";
import { BackgroundGlow } from "../components/BackgroundGlow";
import { WorldMap } from "../components/WorldMap";
import { RouteArc } from "../components/RouteArc";
import { RouteParticle } from "../components/RouteParticle";
import { producerCountries, destinations } from "../data/coffeeData";

export const RoutesScene = () => {
    return (
        <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
            <BackgroundGlow />
            <WorldMap opacity={0.24} scale={1.05} />

            <RouteArc
                from={[producerCountries[0].x, producerCountries[0].y]}
                to={[destinations[0].x, destinations[0].y]}
                delay={0}
                height={170}
            />
            <RouteParticle
                from={[producerCountries[0].x, producerCountries[0].y]}
                to={[destinations[0].x, destinations[0].y]}
                delay={10}
                height={170}
            />

            <RouteArc
                from={[producerCountries[1].x, producerCountries[1].y]}
                to={[destinations[1].x, destinations[1].y]}
                delay={18}
                height={150}
            />
            <RouteParticle
                from={[producerCountries[1].x, producerCountries[1].y]}
                to={[destinations[1].x, destinations[1].y]}
                delay={28}
                height={150}
            />

            <RouteArc
                from={[producerCountries[2].x, producerCountries[2].y]}
                to={[destinations[2].x, destinations[2].y]}
                delay={36}
                height={145}
            />
            <RouteParticle
                from={[producerCountries[2].x, producerCountries[2].y]}
                to={[destinations[2].x, destinations[2].y]}
                delay={46}
                height={145}
            />

            {destinations.map((place) => (
                <div
                    key={place.name}
                    style={{
                        position: "absolute",
                        left: place.x,
                        top: place.y,
                        transform: "translate(-50%, -50%)",
                        color: "#F5E6D3",
                        fontSize: 22,
                        fontWeight: 700,
                        background: "rgba(17,24,39,0.88)",
                        padding: "10px 14px",
                        borderRadius: 999,
                        border: "1px solid rgba(255,255,255,0.08)",
                        boxShadow: "0 8px 20px rgba(0,0,0,0.25)",
                    }}
                >
                    {place.name}
                </div>
            ))}
        </div>
    );
};