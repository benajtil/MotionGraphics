import React from "react";
import { Img, staticFile, useCurrentFrame } from "remotion";
import { fadeIn } from "../utils/animation";
import { theme } from "../styles/theme";
import { BackgroundGlow } from "../components/BackgroundGlow";

export const ComparisonScene = () => {
    const frame = useCurrentFrame();
    const opacity = fadeIn(frame, 0, 16);

    return (
        <div
            style={{
                flex: 1,
                position: "relative",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "0 140px",
                opacity,
            }}
        >
            <BackgroundGlow />

            <div style={{ maxWidth: 760, position: "relative", zIndex: 2 }}>
                <div
                    style={{
                        fontSize: 28,
                        color: theme.colors.amber,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: 1.5,
                        marginBottom: 16,
                    }}
                >
                    From tropical farms
                </div>
                <div
                    style={{
                        fontSize: 66,
                        lineHeight: 1.08,
                        fontWeight: 800,
                    }}
                >
                    To your morning mug
                </div>
                <div
                    style={{
                        marginTop: 18,
                        fontSize: 24,
                        color: theme.colors.cream,
                        lineHeight: 1.5,
                    }}
                >
                    Coffee moves through a vast global network before it reaches your cup.
                </div>
            </div>

            <div
                style={{
                    width: 320,
                    height: 320,
                    borderRadius: "50%",
                    background: "radial-gradient(circle, rgba(198,124,46,0.18), rgba(198,124,46,0.04), transparent 70%)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    boxShadow: "0 0 80px rgba(198,124,46,0.18)",
                    position: "relative",
                    zIndex: 2,
                }}
            >
                <Img
                    src={staticFile("cup-realistic.svg")}
                    style={{
                        width: 190,
                        height: 190,
                        filter: "drop-shadow(0 12px 30px rgba(0,0,0,0.25))",
                    }}
                />
            </div>
        </div>
    );
};