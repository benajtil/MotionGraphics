import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./styles/theme";
import { IntroScene } from "./scenes/IntroScene";
import { ProducersScene } from "./scenes/ProducersScene";
import { RoutesScene } from "./scenes/RoutesScene";
import { StatsScene } from "./scenes/StatsScene";
import { ComparisonScene } from "./scenes/ComparisonScene";
import { OutroScene } from "./scenes/OutroScene";

export const CoffeeVideo = () => {
    return (
        <AbsoluteFill
            style={{
                background: `linear-gradient(180deg, ${theme.colors.bg}, ${theme.colors.bg2})`,
                color: theme.colors.white,
                fontFamily: theme.fontFamily,
                overflow: "hidden",
            }}
        >
            <Sequence from={0} durationInFrames={60}>
                <IntroScene />
            </Sequence>

            <Sequence from={60} durationInFrames={120}>
                <ProducersScene />
            </Sequence>

            <Sequence from={180} durationInFrames={150}>
                <RoutesScene />
            </Sequence>

            <Sequence from={330} durationInFrames={120}>
                <StatsScene />
            </Sequence>

            <Sequence from={450} durationInFrames={90}>
                <ComparisonScene />
            </Sequence>

            <Sequence from={540} durationInFrames={60}>
                <OutroScene />
            </Sequence>
        </AbsoluteFill>
    );
};