import {interpolate, spring} from "remotion";

export const fadeIn = (frame, start = 0, duration = 20) => {
  return interpolate(frame, [start, start + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

export const fadeOut = (frame, start = 0, duration = 20) => {
  return interpolate(frame, [start, start + duration], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

export const popIn = (frame, fps, delay = 0) => {
  return spring({
    frame: frame - delay,
    fps,
    config: {
      damping: 16,
      stiffness: 140,
      mass: 0.9,
    },
  });
};

export const drift = (frame, distance = 20, speed = 120) => {
  return Math.sin(frame / speed) * distance;
};