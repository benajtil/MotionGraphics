export const theme = {
    colors: {
        bg: "#070B14",
        bg2: "#0E1626",
        panel: "rgba(17, 24, 39, 0.82)",
        amber: "#C67C2E",
        amberSoft: "rgba(198, 124, 46, 0.28)",
        cream: "#F5E6D3",
        white: "#F8FAFC",
        muted: "#A8B3C7",
        line: "rgba(255,255,255,0.08)",
        map: "rgba(255,255,255,0.12)",
    },
    fontFamily: "Inter, Arial, sans-serif",
    shadowAmber: "0 0 30px rgba(198,124,46,0.35)",
};