import React from "react";
import { Composition } from "remotion";
import { CoffeeVideo } from "./CoffeeVideo";

export const RemotionRoot = () => {
    return (
        <>
            <Composition
                id="CoffeeVideo"
                component={CoffeeVideo}
                durationInFrames={600}
                fps={30}
                width={1920}
                height={1080}
            />
        </>
    );
};