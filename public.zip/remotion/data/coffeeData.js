export const producerCountries = [
    {
        name: "Brazil",
        x: 540,
        y: 630,
        shortLabel: "Largest exporter",
    },
    {
        name: "Vietnam",
        x: 1320,
        y: 560,
        shortLabel: "Robusta powerhouse",
    },
    {
        name: "Colombia",
        x: 470,
        y: 530,
        shortLabel: "Premium arabica",
    },
];

export const destinations = [
    { name: "North America", x: 350, y: 300 },
    { name: "Europe", x: 910, y: 250 },
    { name: "Philippines", x: 1440, y: 600 },
];

export const stats = [
    { title: "Consumed daily", value: 2250000000, suffix: "" },
    { title: "Producer countries shown", value: 3, suffix: "" },
    { title: "Miles travelled", value: 7000, suffix: "+" },
];