import React from "react";
import { Player } from "@remotion/player";
import { CoffeeVideo } from "../remotion/CoffeeVideo";

export default function App() {
  return (
    <div className="app-shell">
      <div className="content">
        <div className="text-block">
          <p className="eyebrow">AI-Powered Motion Graphics</p>
          <h1>Bean to Brew</h1>
          <p className="subtitle">
            A short documentary-style coffee journey animation built with React,
            Vite, and Remotion.
          </p>
        </div>

        <div className="player-wrap">
          <Player
            component={CoffeeVideo}
            durationInFrames={600}
            fps={30}
            compositionWidth={1920}
            compositionHeight={1080}
            controls
            style={{
              width: "100%",
              aspectRatio: "16 / 9",
              borderRadius: 24,
              overflow: "hidden",
            }}
          />
        </div>
      </div>
    </div>
  );
}